﻿namespace MyRFIDTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gBTrace = new System.Windows.Forms.GroupBox();
            this.RTB_Trace = new System.Windows.Forms.RichTextBox();
            this.gBCommand = new System.Windows.Forms.GroupBox();
            this.TB_UID = new System.Windows.Forms.TextBox();
            this.TB_Version = new System.Windows.Forms.TextBox();
            this.TB_HB = new System.Windows.Forms.TextBox();
            this.Btn_GetUID = new System.Windows.Forms.Button();
            this.Btn_Version = new System.Windows.Forms.Button();
            this.Btn_Heartbeat = new System.Windows.Forms.Button();
            this.Btn_Send = new System.Windows.Forms.Button();
            this.TB_Cmd = new System.Windows.Forms.TextBox();
            this.gBConnection = new System.Windows.Forms.GroupBox();
            this.CB_Baud = new System.Windows.Forms.ComboBox();
            this.TB_COMPort = new System.Windows.Forms.TextBox();
            this.Btn_Connect = new System.Windows.Forms.Button();
            this.gBTrace.SuspendLayout();
            this.gBCommand.SuspendLayout();
            this.gBConnection.SuspendLayout();
            this.SuspendLayout();
            // 
            // gBTrace
            // 
            this.gBTrace.Controls.Add(this.RTB_Trace);
            this.gBTrace.Location = new System.Drawing.Point(8, 332);
            this.gBTrace.Name = "gBTrace";
            this.gBTrace.Size = new System.Drawing.Size(397, 145);
            this.gBTrace.TabIndex = 6;
            this.gBTrace.TabStop = false;
            this.gBTrace.Text = "Message Trace";
            // 
            // RTB_Trace
            // 
            this.RTB_Trace.Location = new System.Drawing.Point(0, 19);
            this.RTB_Trace.Name = "RTB_Trace";
            this.RTB_Trace.Size = new System.Drawing.Size(397, 126);
            this.RTB_Trace.TabIndex = 0;
            this.RTB_Trace.Text = "";
            // 
            // gBCommand
            // 
            this.gBCommand.Controls.Add(this.TB_UID);
            this.gBCommand.Controls.Add(this.TB_Version);
            this.gBCommand.Controls.Add(this.TB_HB);
            this.gBCommand.Controls.Add(this.Btn_GetUID);
            this.gBCommand.Controls.Add(this.Btn_Version);
            this.gBCommand.Controls.Add(this.Btn_Heartbeat);
            this.gBCommand.Controls.Add(this.Btn_Send);
            this.gBCommand.Controls.Add(this.TB_Cmd);
            this.gBCommand.Location = new System.Drawing.Point(8, 101);
            this.gBCommand.Name = "gBCommand";
            this.gBCommand.Size = new System.Drawing.Size(397, 220);
            this.gBCommand.TabIndex = 5;
            this.gBCommand.TabStop = false;
            this.gBCommand.Text = "Commands";
            // 
            // TB_UID
            // 
            this.TB_UID.Location = new System.Drawing.Point(221, 134);
            this.TB_UID.Name = "TB_UID";
            this.TB_UID.ReadOnly = true;
            this.TB_UID.Size = new System.Drawing.Size(156, 20);
            this.TB_UID.TabIndex = 7;
            // 
            // TB_Version
            // 
            this.TB_Version.Location = new System.Drawing.Point(221, 85);
            this.TB_Version.Name = "TB_Version";
            this.TB_Version.ReadOnly = true;
            this.TB_Version.Size = new System.Drawing.Size(100, 20);
            this.TB_Version.TabIndex = 6;
            // 
            // TB_HB
            // 
            this.TB_HB.Location = new System.Drawing.Point(221, 36);
            this.TB_HB.Name = "TB_HB";
            this.TB_HB.ReadOnly = true;
            this.TB_HB.Size = new System.Drawing.Size(100, 20);
            this.TB_HB.TabIndex = 5;
            // 
            // Btn_GetUID
            // 
            this.Btn_GetUID.Location = new System.Drawing.Point(28, 128);
            this.Btn_GetUID.Name = "Btn_GetUID";
            this.Btn_GetUID.Size = new System.Drawing.Size(117, 30);
            this.Btn_GetUID.TabIndex = 4;
            this.Btn_GetUID.Text = "Scan Tag";
            this.Btn_GetUID.UseVisualStyleBackColor = true;
            this.Btn_GetUID.Click += new System.EventHandler(this.Btn_GetUID_Click);
            // 
            // Btn_Version
            // 
            this.Btn_Version.Location = new System.Drawing.Point(28, 77);
            this.Btn_Version.Name = "Btn_Version";
            this.Btn_Version.Size = new System.Drawing.Size(117, 35);
            this.Btn_Version.TabIndex = 3;
            this.Btn_Version.Text = "Get Software Version";
            this.Btn_Version.UseVisualStyleBackColor = true;
            this.Btn_Version.Click += new System.EventHandler(this.Btn_Version_Click);
            // 
            // Btn_Heartbeat
            // 
            this.Btn_Heartbeat.Location = new System.Drawing.Point(28, 29);
            this.Btn_Heartbeat.Name = "Btn_Heartbeat";
            this.Btn_Heartbeat.Size = new System.Drawing.Size(117, 33);
            this.Btn_Heartbeat.TabIndex = 2;
            this.Btn_Heartbeat.Text = "Get Heartbeat";
            this.Btn_Heartbeat.UseVisualStyleBackColor = true;
            this.Btn_Heartbeat.Click += new System.EventHandler(this.Btn_Heartbeat_Click);
            // 
            // Btn_Send
            // 
            this.Btn_Send.Location = new System.Drawing.Point(302, 171);
            this.Btn_Send.Name = "Btn_Send";
            this.Btn_Send.Size = new System.Drawing.Size(75, 31);
            this.Btn_Send.TabIndex = 1;
            this.Btn_Send.Text = "Send";
            this.Btn_Send.UseVisualStyleBackColor = true;
            this.Btn_Send.Click += new System.EventHandler(this.Btn_Send_Click);
            // 
            // TB_Cmd
            // 
            this.TB_Cmd.AccessibleDescription = "custom command";
            this.TB_Cmd.Location = new System.Drawing.Point(20, 177);
            this.TB_Cmd.Name = "TB_Cmd";
            this.TB_Cmd.Size = new System.Drawing.Size(263, 20);
            this.TB_Cmd.TabIndex = 0;
            this.TB_Cmd.Tag = "custom command";
            // 
            // gBConnection
            // 
            this.gBConnection.Controls.Add(this.CB_Baud);
            this.gBConnection.Controls.Add(this.TB_COMPort);
            this.gBConnection.Controls.Add(this.Btn_Connect);
            this.gBConnection.Location = new System.Drawing.Point(8, 10);
            this.gBConnection.Name = "gBConnection";
            this.gBConnection.Size = new System.Drawing.Size(397, 76);
            this.gBConnection.TabIndex = 4;
            this.gBConnection.TabStop = false;
            this.gBConnection.Text = "Connection";
            // 
            // CB_Baud
            // 
            this.CB_Baud.FormattingEnabled = true;
            this.CB_Baud.Items.AddRange(new object[] {
            "19200",
            "38400",
            "57600"});
            this.CB_Baud.Location = new System.Drawing.Point(121, 29);
            this.CB_Baud.Name = "CB_Baud";
            this.CB_Baud.Size = new System.Drawing.Size(76, 21);
            this.CB_Baud.TabIndex = 2;
            this.CB_Baud.Text = "19200";
            // 
            // TB_COMPort
            // 
            this.TB_COMPort.Location = new System.Drawing.Point(28, 29);
            this.TB_COMPort.Name = "TB_COMPort";
            this.TB_COMPort.Size = new System.Drawing.Size(73, 20);
            this.TB_COMPort.TabIndex = 1;
            this.TB_COMPort.Text = "COM1";
            this.TB_COMPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Btn_Connect
            // 
            this.Btn_Connect.Location = new System.Drawing.Point(221, 22);
            this.Btn_Connect.Name = "Btn_Connect";
            this.Btn_Connect.Size = new System.Drawing.Size(156, 32);
            this.Btn_Connect.TabIndex = 0;
            this.Btn_Connect.Text = "Connect to COM";
            this.Btn_Connect.UseVisualStyleBackColor = true;
            this.Btn_Connect.Click += new System.EventHandler(this.Btn_Connect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 488);
            this.Controls.Add(this.gBTrace);
            this.Controls.Add(this.gBCommand);
            this.Controls.Add(this.gBConnection);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyRFIDTool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.gBTrace.ResumeLayout(false);
            this.gBCommand.ResumeLayout(false);
            this.gBCommand.PerformLayout();
            this.gBConnection.ResumeLayout(false);
            this.gBConnection.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gBTrace;
        private System.Windows.Forms.RichTextBox RTB_Trace;
        private System.Windows.Forms.GroupBox gBCommand;
        private System.Windows.Forms.TextBox TB_UID;
        private System.Windows.Forms.TextBox TB_Version;
        private System.Windows.Forms.TextBox TB_HB;
        private System.Windows.Forms.Button Btn_GetUID;
        private System.Windows.Forms.Button Btn_Version;
        private System.Windows.Forms.Button Btn_Heartbeat;
        private System.Windows.Forms.Button Btn_Send;
        private System.Windows.Forms.TextBox TB_Cmd;
        private System.Windows.Forms.GroupBox gBConnection;
        private System.Windows.Forms.TextBox TB_COMPort;
        private System.Windows.Forms.Button Btn_Connect;
        private System.Windows.Forms.ComboBox CB_Baud;

    }
}

