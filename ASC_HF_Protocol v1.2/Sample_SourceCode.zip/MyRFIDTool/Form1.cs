﻿/******************************************************************************
 *                                  DISCLAIMER OF WARRANTY 
 * 
 * THIS NOTICE MAY NOT BE REMOVED FROM THE PROGRAM BY ANY USER THEREOF. 
 * 
 *
 * This source code is provided "as is" without any express or implied warranties whatsoever. 
 * Because of the diversity of conditions and hardware under which this source code may be used,
 * no warranty of fitness for a particular purpose is offered. The user is advised to test the 
 * source code thoroughly before relying on it. The user must assume the entire risk of using 
 * the source code.
 * 
 * Copyright:   Brooks Automation (Germany) GmbH
 * 
 *****************************************************************************/
/*****************************************************************************/
/*  
/*    P r o j e c t         &P:         MyRFIDTool
/*    C o m p o n e n t     &K:         Sample Program
/*    V E R S I O N         &V:         1.0
/*    D a t e  (JJ MM TT)   &D:         20.07.2009
/*    A u t h o r           &E:         S.G.
/*    M o d u l             &M:         
/*****************************************************************************/
/*    D e s c r i p t i o n: 
/*****************************************************************************/
/*    H i s t o r y : 
/*    date person version comment 
/*    --------------------------------------------------------------
/*                  Version 1.0   MyRFIDTool 
/*    20.07.09  	S.G.  First official Version
/*                  Tool aims at binding the ASCHFProtLib.dll and 
/*                  using it to perform basic RFID functions.
/* 
/*****************************************************************************/



using System;
using System.Text;
using System.Windows.Forms;

namespace MyRFIDTool
{
    public partial class Form1 : Form
    {
        ASCHFProtLib.HFProt         m_Prot;     //Object of DLL. Performs all protocol tasks.        
        bool                        m_Connected;//Flag indicates if port is connected. 

        public Form1()
        {
            InitializeComponent();
            CB_Baud.SelectedIndex = 0;

            m_Prot = new ASCHFProtLib.HFProt();
            m_Prot.OnRS232AscMsg += new ASCHFProtLib.HFProt.MsgRS232Received(OnRS232AscMsg);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_Prot != null)
            {
                if (m_Prot.RS232Connected)
                    m_Prot.CloseRSCom();            //Close port, if Open      

                m_Prot.Dispose();               //Free the object!
                m_Prot = null;
            }
        }


        #region Button Clicks
        private void Btn_Connect_Click(object sender, EventArgs e)
        {
            if (!m_Connected)                           //If NOT already connected
            {
                if (m_Prot != null)              //safe to check if object exists
                {
                    //Open the port now.
                    if (m_Prot.OpenRSCom(Convert.ToInt32(CB_Baud.Text), TB_COMPort.Text)) ;
                    {
                        m_Connected = m_Prot.RS232Connected;
                    }
                }
            }
            else                                        //We are already connected!!
            {
                m_Prot.CloseRSCom();
                m_Connected = m_Prot.RS232Connected;
            }

            //en-/disable the input fields
            this.TB_COMPort.Enabled = !m_Connected;
            this.CB_Baud.Enabled = !m_Connected;
            this.gBCommand.Enabled = m_Connected;

            //Update labels & button text as per status.
            if (m_Connected)
            {
                Btn_Connect.Text = "Disconnect";
            }
            else
            {
                Btn_Connect.Text = "Connect to COM";
            }
                
        }
        private void Btn_Heartbeat_Click(object sender, EventArgs e)
        {
            m_Prot.SendRS232("H0");
            Add2Trace("<< H0");                     //show in Trace
        }

        private void Btn_Version_Click(object sender, EventArgs e)
        {
            m_Prot.SendRS232("V0");
            Add2Trace("<< V0");                     //show in Trace
        }

        private void Btn_GetUID_Click(object sender, EventArgs e)
        {
            m_Prot.SendRS232("M01");               //Read on Antenna Port 1
            Add2Trace("<< M01");                     //show in Trace
        }

        private void Btn_Send_Click(object sender, EventArgs e)
        {
            m_Prot.SendRS232(TB_Cmd.Text);
            Add2Trace("<< " + TB_Cmd.Text);
        }
        #endregion
        #region Fired Events
        void OnRS232AscMsg(object sender, string AscMsg)
        {
            Add2Trace(">>" + AscMsg);                   //show in Trace

            processASCMsg(AscMsg);                      //process ASCII message
        }

        #endregion

        #region Events & Delegates
        private delegate void BoolCallBack(bool b);
        private delegate void StringCallBack(string msg);

        private void processASCMsg(string AscMsg)
        {
            if (RTB_Trace.InvokeRequired)
            {
                StringCallBack d = new StringCallBack(processASCMsg);
                this.Invoke(d, new object[] { AscMsg });
            }
            else
            {
                char cmd = AscMsg[0];

                try
                {
                    switch (cmd)
                    {
                        case 'h': //Heartbeat
                            TB_HB.Text = AscMsg.Substring(2, 4);
                            break;
                        case 'v': //Software Version
                            string sHexVersion = AscMsg.Substring(2);

                            //Convert HEX string into ASCII format
                            byte[] buffer = new byte[sHexVersion.Length / 2];
                            for (int i = 0; i < sHexVersion.Length; i += 2)
                            {
                                buffer[i / 2] = (byte)Convert.ToByte(sHexVersion.Substring(i, 2), 16);
                            }

                            TB_Version.Text = Encoding.ASCII.GetString(buffer);

                            break;
                        case 'm':
                            if (AscMsg.Length > 10)
                            {
                                TB_UID.Text = AscMsg.Substring(5);
                            }
                            break;
                    }
                }
                catch (Exception ec)
                {
                    MessageBox.Show("Error! " + ec.Message);
                }
            }
        }
       
        private void Add2Trace(string TraceMsg)
        {
            if (RTB_Trace.InvokeRequired)
            {
                StringCallBack d = new StringCallBack(Add2Trace);
                this.Invoke(d, new object[] { TraceMsg });
            }
            else
            {
                RTB_Trace.AppendText(TraceMsg + "\r\n");
                RTB_Trace.ScrollToCaret();
            }
        }
        #endregion

        
       
    }
}
